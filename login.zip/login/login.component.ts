import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms'
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {


  email = "";
  password = "";
  errorMsg = "";

  public loginForm !: FormGroup;

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router: Router,private auth: AuthService) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: [''],
      password: [''],
    })
  }

    validations() {
      if (this.email.trim().length === 0) {
        this.errorMsg = "Username is required";
      } else if (this.password.trim().length === 0) {
        this.errorMsg = "Password is required";
      } else {
        this.errorMsg = "";
        let res = this.auth.login(this.email, this.password);
        if (res === 200) {
          this.router.navigate(['home'])
        }
        if (res === 403) {
          this.errorMsg = "Wrong credential";
        }
      }
    }
  

  login() {

    this.http.get<any>("http://localhost:61755/signupUsers")

      .subscribe(res => {
        const user = res.find((a: any)=> {
          return a.email === this.loginForm.value.email && a.password === this.loginForm.value.password
        });
    if (user && user.role!="admin") {
      alert("login successfull!");
      this.loginForm.reset();
      this.router.navigate(['userhome']);
    } 
    else if (user.email=="aishwaryaka@cybage.com" && user.password=="12" && user.role=="admin") {
      console.log("Admin part 1");
      alert("Welcome Admin!!");
      this.loginForm.reset();
      this.router.navigate(['adminhome']);
      console.log("Admin part 2");
    } else {
      alert("user not found");
    }
  },err=>{
  alert("something went wrong");
})
  }
}


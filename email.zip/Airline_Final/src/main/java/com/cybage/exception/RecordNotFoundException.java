package com.cybage.exception;

public class RecordNotFoundException extends Exception{

	

	public RecordNotFoundException(String message) {
		super(message);
		
	}
	
}

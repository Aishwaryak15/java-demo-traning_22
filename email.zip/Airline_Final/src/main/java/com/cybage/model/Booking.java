package com.cybage.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {
	
	@Id
	private int bookingId;
	@Column
	private String source;
	@Column
	private String destination;
	@Column
	private double fare;
	
	@OneToOne(mappedBy = "booking")
    private Passenger passenger;
	
	@OneToOne(mappedBy = "booking")
    private Complaint complaint;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
    private Flight flight;

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Booking(int bookingId, String source, String destination, double fare, Passenger passenger,
			Complaint complaint, Flight flight) {
		super();
		this.bookingId = bookingId;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
		this.passenger = passenger;
		this.complaint = complaint;
		this.flight = flight;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", source=" + source + ", destination=" + destination + ", fare="
				+ fare + ", passenger=" + passenger + ", complaint=" + complaint + ", flight=" + flight + "]";
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	public Complaint getComplaint() {
		return complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	
	
	
}

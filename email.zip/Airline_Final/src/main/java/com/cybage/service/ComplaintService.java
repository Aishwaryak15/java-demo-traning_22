package com.cybage.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.ComplaintDao;
import com.cybage.model.Complaint;

@Service
public class ComplaintService {

	@Autowired
	private ComplaintDao complaintDao;

	public Complaint addComplaint(Complaint complain) {
		return complaintDao.save(complain);
	}

	public List<Complaint> getAllComplaints() {
		List<Complaint> complains = new ArrayList<Complaint>();
		complaintDao.findAll().forEach(complain1 -> complains.add(complain1));
		return complains;
	}

	public Complaint updateComplaint(Complaint complain) {
		return complaintDao.save(complain);
	}

	public boolean deleteById(int complainId) {
		if (complaintDao.existsById(complainId)) {
			complaintDao.deleteById(complainId);
			return true;
		}
		return false;
	}

	public Complaint findById(int id) {
		Optional<Complaint> complain = complaintDao.findById(id);
		return complain.orElse(null);
	}
	
	public boolean deleteAll() {
		complaintDao.deleteAll();
		return false;
	}
	
}

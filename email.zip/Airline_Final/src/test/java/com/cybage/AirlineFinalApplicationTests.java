package com.cybage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}

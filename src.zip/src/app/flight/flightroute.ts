export class FlightRoute {
    source!:string
    stop1!:string
    stop2!:number
    destination!:number
    economyPrice!:number
   businessPrice!:number
   premiumPrice!:number

}
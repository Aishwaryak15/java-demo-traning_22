import { Component, OnInit } from '@angular/core';
import { RouteDialogComponent } from '../route-dialog/route-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { FlightRoute } from '../flightroute';
import { MatTableDataSource } from '@angular/material/table';
import { FlightrouteService } from '../flightroute.service';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-route-list',
  templateUrl: './route-list.component.html',
  styleUrls: ['./route-list.component.css'],
})
export class RouteListComponent implements OnInit {
  displayedColumns: any[] = [
    'image',
    'flightRouteId',
    'source',
    'stop1',
    'stop2',
    'destination',
    'economyPrice',
    'businessPrice',
    'premiumPrice',
    'actions',
  ];
  flightRouteList!: FlightRoute[];
  dataSource = new MatTableDataSource(this.flightRouteList);
  constructor(
    private dialog: MatDialog,
    private _flightRouteService: FlightrouteService
  ) {}

  ngOnInit(): void {
    this.getFlightRouteList();
  }
  openDialog() {
    this.dialog
      .open(RouteDialogComponent, {})
      .afterClosed()
      .subscribe((val) => {
        if (val == 'save') {
        }
      });
  }
  updateflightRoute(row: any) {
    this.dialog.open(RouteDialogComponent, {
      data: row,
    });
  }
  deleteflightRoute(id: number) {}
  getFlightRouteList() {
    this._flightRouteService.getFlightRouteList().subscribe({
      next: (res) => {
        this.flightRouteList = res;
        console.log(this.flightRouteList);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}

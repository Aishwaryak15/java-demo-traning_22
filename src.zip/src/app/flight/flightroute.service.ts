import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FlightRoute } from './flightroute';

@Injectable({
  providedIn: 'root'
})
export class FlightrouteService {
private baseURL="http://localhost:8080/flightRoute"
  constructor(private _http:HttpClient) { }

  addFlight(flightRoute:FlightRoute):Observable<any>{
    return this._http.post(`${this.baseURL}/add-route`,flightRoute, {responseType: 'text'})
  }
  getFlightRouteList():Observable<any>{
   return this._http.get(`${this.baseURL}/get-all-routes`)
  }
  updateFlightRoute(id:number,flightRoute:FlightRoute):Observable<any>{
    console.log(flightRoute)
    return this._http.put(`${this.baseURL}/update-route/${id}`,flightRoute,{responseType: 'text'})
  }
  deleteFlightRoue(id:number):Observable<any>{
    return this._http.delete(`${this.baseURL}/delete-flight-by-id/${id}`,{responseType: 'text'})
  }

}

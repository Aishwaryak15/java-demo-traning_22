import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from './flight/dialog/dialog.component';
import { FlightService } from './flight/flight.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'AdminFlightReservationSystem';
  constructor(
    private dialog: MatDialog,
    private _flightServie: FlightService
  ) {}
  openDialog() {
    this.dialog.open(DialogComponent, {}).afterClosed();
  }
}

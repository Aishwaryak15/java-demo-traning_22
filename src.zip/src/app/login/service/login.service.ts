import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { User } from '../../model/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class LoginService {

  private baseUrl = 'http://localhost:8082';

  constructor(private http:HttpClient){ }

  registerUser(user: Object): Observable<Object>{
    localStorage.setItem("currentUser",JSON.stringify(user));
    return this.http.post('http://localhost:8082/registerUser', user);
  }

  loginCheck(user: Object): Observable<Object>{
    return this.http.post('http://localhost:8082/checklogin', user);
  }

  goForValidation(otpCredentials: Object): Observable<any>{
    return this.http.post('http://localhost:8082/checkOtpValidation', otpCredentials);
  }

  // baseUrl = 'http://localhost:8082/checklogin';
  // constructor(private _http: HttpClient) {}
  // public checklogin(user: User): Observable<any> {
  //   return this._http.post<any>('http://localhost:8082/checklogin', user);
  // }
  // public registerUser(user: User): Observable<any> {
  //   return this._http.post<any>(
  //     'http://localhost:8082/registerUser',
  //     user
  //   );
  // }

  // public goForValidation(otpCredentials: object): Observable<any> {
  //   return this._http.post<any>(
  //     'http://localhost:8082/checkOtpValidation',
  //     otpCredentials,
  //     {
  //       responseType: 'text' as 'json',
  //     }
  //   );
  // }
}

export class User {
    userId!: number;
  role!:number;
  userName!:string;
  userEmail!:string;
  password!: string;
  dob!: string;
  contactNo!:string;
  gender!:string;
}

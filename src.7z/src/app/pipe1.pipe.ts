import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipe1' //here we are searching details
})
export class Pipe1Pipe implements PipeTransform {

  transform(value: any[], args: string): any {
    if(!value) return null;
    if(!args) return value;
    let pipe1=args.toLowerCase();  
    return value.filter(employee=>{
      let employeeName=employee.name.toLowerCase();
        return employeeName.indexOf(pipe1) !== -1;
    });
  }

}
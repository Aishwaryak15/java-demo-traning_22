import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginDialogComponent } from '../../login-dialog/login-dialog.component';
import { MaterialModule } from 'src/app/customModules/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgOtpInputModule } from 'ng-otp-input';
import { OtpComponentComponent } from '../../otp-component/otp-component.component';
import { RegistrationComponent } from '../../registration/registration.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    LoginDialogComponent,
    OtpComponentComponent,
    RegistrationComponent,
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NgOtpInputModule,
    RouterModule,
  ],
})
export class LoginModule {}

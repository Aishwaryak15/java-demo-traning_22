import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../../model/user';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-dialog',
  templateUrl: './login-dialog.component.html',
  styleUrls: ['./login-dialog.component.css'],
})
export class LoginDialogComponent implements OnInit {
  user: User = new User;
  msg = ' ';
  loginForm = this.formBuilder.group({
    userEmail: ['', [Validators.required]],
    password: ['', Validators.required],
  });
  constructor(
    private formBuilder: FormBuilder,
    private _loginService: LoginService,
    private _router: Router
  ) {}

  ngOnInit(): void {}

  // resetForm() {}

  OnSubmit() {
    this.user = this.loginForm.value;
    
    let email = this.user.userEmail;
    let pass = this.user.password;
    if((email!==null && pass!==null) && (email!='' && pass != ''))
    {
      this.LoginUser();
      this.otpPage();
    }else {
      this._router.navigate(['/login']);
    }
   
   }
  otpPage() {
    this._router.navigate(['/otpVerification', this.user.userEmail]);
  }
  LoginUser() {
    this._loginService.loginCheck(this.user).subscribe({
      next: (res) => {
        console.log(res);
      },
      error: (err) => {
        console.log(err);
        this.msg = 'Bad Credentials, please enter valid emailId and password';
      },
    });
  }
}

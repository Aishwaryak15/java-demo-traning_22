import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { User } from '../../model/user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
})
export class RegistrationComponent implements OnInit {
  user = new User();
  constructor(
    private formBuilder: FormBuilder,
    private _loginService: LoginService,
    private _router: Router
  ) {}

  registerForm = this.formBuilder.group({
    userName: ['', [Validators.required]],
    userEmail: ['', [Validators.required]],
    contactNo: ['', [Validators.required]],
    password: ['', Validators.required],
    dob: ['', [Validators.required]],
    gender: ['', [Validators.required]],
    // role: ['', [Validators.required]],
  });
  ngOnInit(): void {}

  OnSubmit() {
    this.user = this.registerForm.value;
    this.RegisterUser();
  }

 

  RegisterUser() {
    this._loginService.registerUser(this.user).subscribe({
      next: (res) => {
        console.log(res);
        this._router.navigate(['flight']);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgOtpInputComponent } from 'ng-otp-input';
import { User } from 'src/app/model/user';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-otp-component',
  templateUrl: './otp-component.component.html',
  styleUrls: ['./otp-component.component.css'],
})
export class OtpComponentComponent implements OnInit {
  userEmail: string = '';
  // role:number='';
  otp: string = '';
  otpCredentials = {};
  showOtpComponent = true;
  @ViewChild('ngOtpInput', { static: false }) ngOtpInput: any;
  config = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: '*',
    inputStyles: { width: '50px', height: '50px' },
  };
  // data2: any;
  // role: any;
  // user: any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private rout: Router,
    private userService: LoginService
  ) {}

  ngOnInit(): void {
    this.userEmail = this.activatedRoute.snapshot.params['userEmail'];
  }

  onOtpChange(otp: any) {
    this.otp = otp;
    console.log(otp);
  }

//  goForValidation(){
//   this.otpCredentials={userEmail:this.userEmail, verificationCode:this.otp}
//   this.userService.goForValidation(this.otpCredentials).subscribe({
//    next:(data)=>{
//   this.data2=data;
//    localStorage.setItem("User",JSON.stringify(data));
//   this.role=this.data2.role;
//   this.role===2?localStorage.setItem("userType","admin"):localStorage.setItem("userType","user")
//   if(this.role == 2)
//    {
//   this.rout.navigate(['flight']);
//   // this.dialogref.close(OtpComponentComponent);
    
//         }
//        else
//          {
//           this.rout.navigate(['/searchFlight']);
//           alert('loggedin success');
//         //  this.dialogref.close(OtpComponentComponent);
//           }
//            this.user = new User();
    
//          },error:(err)=>{
//         console.log(err);
    
//         alert("invalid otp")
    
//          }
//        });
  goForValidation() {
    this.otpCredentials = { email: this.userEmail,  otp: this.otp };
    this.userService.goForValidation(this.otpCredentials).subscribe(
      (data) => {
        console.log(data);
        localStorage.setItem('userDetails', JSON.stringify(data)); //localStorage.removeItem('userDetails'); to logout
        this.rout.navigate(['flight']);
        alert('loggedin success');
      },
      (error) => {
        console.log(error);
        alert('failed');
      }
    );
  }
}

  
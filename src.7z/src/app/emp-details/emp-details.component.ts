import { Component, OnInit } from '@angular/core';
import  {Employee} from 'src/utility/Employee';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.scss']
})
export class EmpDetailsComponent implements OnInit {

employees :Employee[]=[{empid:101,name:"Abhi",designation:"Manager",image:'https://th.bing.com/th/id/R.5857dd8eb917b62ef2fde2ace30a9f5e?rik=EofpG2C5WtNV5w&riu=http%3a%2f%2f4.bp.blogspot.com%2f-g3XaBhx6f_Q%2fUAkLd_jx4BI%2fAAAAAAAAHac%2foVomqd8sjj4%2fs1600%2fHDhut.blogspot.com%2b(21).jpg&ehk=ot5Guxn5M0b0oFtNFBu6JTZmQm4tp0XHj4SKL%2fTbBCA%3d&risl=&pid=ImgRaw&r=0',flag:true},
{empid:102,name:"Ash",designation:"Trainee",image:'https://th.bing.com/th/id/OIP.9RUImVT7r0tBKvAUs9XKpwHaEo?pid=ImgDet&rs=1',flag:true},
{empid:103,name:"twinkle",designation:"TL",image:'https://i2.wp.com/picsdownloadz.com/wp-content/uploads/2014/08/Beautiful-Photos-of-Tunnel-of-Love-in-Kleven-Ukraine-Picture-Collections.jpg?resize=1024%2C663',flag:true}]


searchStr:string="";

  constructor() {
    console.log("constructor");
   }

  name:string="Aishwarya Kahane";

  ngOnInit(): void {
    console.log("OnInit");
  }

  toggleImage(employees: Employee){
    employees.flag=! employees.flag;
  }
  msg: string="Hiii Aishwarya"
  cur:number=175;

}

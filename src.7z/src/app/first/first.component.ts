import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.scss'],
  template: `User Name: <input type="text" [(ngModel)]="userName"  ><br/>
    {{userName}}`
})
export class FirstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  sayHello(){
    alert("hello");
  }
  
}


import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FirstComponent } from './first/first.component';
import { EmpDetailsComponent } from './emp-details/emp-details.component';
import { ConvertToSpacePipe } from './pipes/convert-to-space.pipe';
import { Pipe1Pipe } from './pipe1.pipe';
import { FormsModule } from '@angular/forms';
import { ParentComponent } from './components/parent/parent.component';
import { CounterComponent } from './components/counter/counter.component';
import { NavComponent } from './components/nav/nav.component';
import { ErrorComponent } from './components/error/error.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FirstComponent,
    EmpDetailsComponent,
    ConvertToSpacePipe,
    Pipe1Pipe,
    ParentComponent,
    CounterComponent,
    NavComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
         FormsModule
      
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

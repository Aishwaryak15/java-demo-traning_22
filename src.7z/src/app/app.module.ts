import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './customModules/material.module';

import { HttpClientModule } from '@angular/common/http';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FlightModule } from './flight/flightModules/flight.module';
import { RouteListComponent } from './flight/route-list/route-list.component';
import { LoginModule } from './login/loginModule/login/login.module';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { VerifyComponent } from './verify/verify.component';

@NgModule({
  declarations: [AppComponent, UserhomeComponent, AdminhomeComponent, VerifyComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    FlightModule,
    LoginModule,
    RouterModule,
    CommonModule,
    MatFormFieldModule
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}

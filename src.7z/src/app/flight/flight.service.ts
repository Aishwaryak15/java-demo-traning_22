import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Flight } from './flight';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private baseURL="http://localhost:8080/flight"


  constructor(private _http:HttpClient) { }
     addFlight(flight:Flight):Observable<any>{
       return this._http.post(`${this.baseURL}/add-flight`,flight, {responseType: 'text'})
     }
     getFlightList():Observable<any>{
      return this._http.get(`${this.baseURL}/get-all-flights`)
     }
     updateFlight(id:number,flight:Flight):Observable<any>{
       return this._http.put(`${this.baseURL}/update-flight/${id}`,flight,{responseType: 'text'})
     }
     deleteFlight(id:number):Observable<any>{
       return this._http.delete(`${this.baseURL}/delete-flight/${id}`,{responseType: 'text'})
     }
}

export class Flight {
    flightName!:string
    serviceProvider!:string
    economy!:number
    premium!:number
    business!:number

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightListComponent } from '../flight-list/flight-list.component';
import { DialogComponent } from '../dialog/dialog.component';
import { MaterialModule } from 'src/app/customModules/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouteDialogComponent } from '../route-dialog/route-dialog.component';
import { RouteListComponent } from '../route-list/route-list.component';

@NgModule({
  declarations: [
    FlightListComponent,
    DialogComponent,
    RouteDialogComponent,
    RouteListComponent,
  ],
  imports: [CommonModule, MaterialModule, FormsModule, ReactiveFormsModule],
})
export class FlightModule {}

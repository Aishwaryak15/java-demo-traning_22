import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';


export interface Flightdata {
  flightId: number
  flightName: string
  serviceProvider: string
  economy: number
  premium: number
  business: number
}

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrls: ['./flight-list.component.css']
})
export class FlightListComponent implements OnInit {
  flightList!: Flightdata[];
  flightId!: number
  flight: Flight = new Flight()
  flightName:any
  serviceProvider:any
  id:any
constructor(private _flightSerice: FlightService, private dialog: MatDialog) {}

  ngOnInit(): void {
   this.getFlights();
  }
  nameSearch(){
    
    if(this.flightName==""){
      this.ngOnInit()
    }
    else{
      this.flightList= this.flightList.filter(res=>{
          console.log(res.flightName)
        return res.flightName.toLocaleLowerCase().match(this.flightName.toLocaleLowerCase() ) 
        
      })
    }

  }

 
  serviceSearch(){
    if(this.serviceProvider==""){
      this.ngOnInit()
    }
    else{
      this.flightList= this.flightList.filter(res=>{
     return res.serviceProvider.toLocaleLowerCase().match(this.serviceProvider.toLocaleLowerCase() ) 
         })
    }

  }
  
  dataSource = new MatTableDataSource(this.flightList);
  openDialog() {
    this.dialog.open(DialogComponent, {
     
    }).afterClosed().subscribe(val=>{
      if(val=='save')
      this.getFlights()
    })
    
}
  getFlights() {
    this._flightSerice.getFlightList().subscribe( {
        next:(res)=>{
          this.flightList=res
        },
        error:(err)=>{
        console.log(err)
         
        }
      
    })
  }
  displayedColumns: any[] = ['image','flightId', 'flightName', 'serviceProvider', 'economy', 'premium', 'business', 'actions',];
  updateflight(row: any) {
    this.dialog.open(DialogComponent, {
      data: row
    }).afterClosed().subscribe(val => {
      if (val == 'update') {
        this.getFlights()
      }})


  }
  deleteflight(id: number) {
    console.log(id)
    if (id!=null){
      this._flightSerice.deleteFlight(id)
      .subscribe({
        next:(res)=>{
         this.getFlights()
        
       
        },
        error:(err)=>{
          this.getFlights()
       
        }
     
    })
    }
    else{
      this.getFlights()
    }
   

  }
}

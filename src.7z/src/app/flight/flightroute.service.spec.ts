import { TestBed } from '@angular/core/testing';

import { FlightrouteService } from './flightroute.service';

describe('FlightrouteService', () => {
  let service: FlightrouteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FlightrouteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  flight: Flight = new Flight()
  flightForm = this.formBuilder.group({
    flightName: ['',[Validators.required]],
    serviceProvider: ['',Validators.required],
    economy: ['',Validators.required],
    premium: ['',Validators.required],
    business: ['',Validators.required]
  })
  actionBtn: String = "Add Flight"

  constructor(private formBuilder: FormBuilder, private _flightService: FlightService,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialogRef: MatDialogRef<DialogComponent>,) { }
  ngOnInit(): void {

    if (this.editData) {
      this.actionBtn = "update"
      this.flightForm.controls['flightName'].setValue(this.editData.flightName)
      this.flightForm.controls['serviceProvider'].setValue(this.editData.serviceProvider)
      this.flightForm.controls['economy'].setValue(this.editData.economy)
      this.flightForm.controls['premium'].setValue(this.editData.premium)
      this.flightForm.controls['business'].setValue(this.editData.business)
    }
  }

 
  OnSubmit() {
    this.actionBtn = "save"
    this.flight = this.flightForm.value;
    this.saveFlight();
    this.flightForm.reset()
    this.dialogRef.close('save')
  }

  resetForm(){
    this.flightForm.reset()
  }


  saveFlight() {
    if (!this.editData) {
      this._flightService.addFlight(this.flight).subscribe({
        next: (res) => {
        
          this.dialogRef.close('save')
        },
        error: (err) => {
          console.log(err)
          alert("Error while Adding Product")
        }
})

    }
    else {
      this.updateFlight()
    }
  }
  updateFlight() {
    this._flightService.updateFlight(this.editData.flightId, this.flightForm.value)
      .subscribe({
        next: (res) => {
          alert("Flight Updated Successfully")
          this.flightForm.reset()
          this.dialogRef.close('update')
        },
        error: () => {
          alert("Error While updating Flight")
        }
      })

  }

}

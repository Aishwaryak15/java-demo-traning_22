import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormGroup } from '@angular/forms';
import { FlightRoute } from '../flightroute';
import { FlightrouteService } from '../flightroute.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-route-dialog',
  templateUrl: './route-dialog.component.html',
  styleUrls: ['./route-dialog.component.css']
})
export class RouteDialogComponent implements OnInit {
  flightRoute!:FlightRoute
  flightRouteForm = this.formBuilder.group({
  source: ['',[Validators.required]],
    stop1: ['',Validators.required],
    stop2: ['',Validators.required],
    destination: ['',Validators.required],
    economyPrice: ['',Validators.required],
    businessPrice: ['',Validators.required],
    premiumPrice: ['',Validators.required]
  })
  actionBtn: String = "Add Route"
  constructor(private formBuilder:FormBuilder,
    private _flightRouteService:FlightrouteService,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialogRef: MatDialogRef<DialogComponent>,
    ) { }

  ngOnInit(): void {
    if (this.editData) {
      this.actionBtn = "update"
      this.flightRouteForm.controls['source'].setValue(this.editData.source)
      this.flightRouteForm.controls['stop1'].setValue(this.editData.stop1)
      this.flightRouteForm.controls['stop2'].setValue(this.editData.stop2)
      this.flightRouteForm.controls['destination'].setValue(this.editData.destination)
      this.flightRouteForm.controls['economyPrice'].setValue(this.editData.economyPrice)
      this.flightRouteForm.controls['premiumPrice'].setValue(this.editData.premiumPrice)
      this.flightRouteForm.controls['businessPrice'].setValue(this.editData.businessPrice)
    }
  
  }
  resetForm(){
    this.flightRouteForm.reset()
  }
  OnRouteSubmit(){
   this.flightRoute=this.flightRouteForm.value
   this.saveRoute();

  }
  saveRoute(){
    if (!this.editData) {
    this._flightRouteService.addFlight(this.flightRoute).subscribe({
      next: (res) => {
      console.log(res)
      //  this.dialogRef.close('save')
      },
      error: (err) => {
        console.log(err)
        alert("Error while Adding Product")
      }
})
    }
     else{
      this.updateFlightRoute()
     }
  }
  updateFlightRoute() {
    this._flightRouteService.updateFlightRoute(this.editData.flightRouteId, this.flightRouteForm.value)
      .subscribe({
        next: (res) => {
          alert("Flight Updated Successfully")
          this.flightRouteForm.reset()
          this.dialogRef.close('update')
        },
        error: () => {
          alert("Error While updating Flight")
        }
      })

  }


}

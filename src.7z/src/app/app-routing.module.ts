import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightListComponent } from './flight/flight-list/flight-list.component';
import { FlightModule } from './customModules/flight.module';
import { RouteDialogComponent } from './flight/route-dialog/route-dialog.component';
import { RouteListComponent } from './flight/route-list/route-list.component';
import { LoginDialogComponent } from './login/login-dialog/login-dialog.component';
import { OtpComponentComponent } from './login/otp-component/otp-component.component';
import { RegistrationComponent } from './login/registration/registration.component';
import { VerifyComponent } from './verify/verify.component';

const routes: Routes = [
  {
    path: 'flight',
    component: FlightListComponent,
  },
  {
    path: 'route',
    component: RouteListComponent,
  },
  {
    path: 'login',
    component: LoginDialogComponent,
  },
  {
    path: 'otpVerification/:userEmail',
    component: OtpComponentComponent,
  },
  {
    path: 'registration',
    component: RegistrationComponent,
  },
  {
    path: 'verify',
    component: VerifyComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

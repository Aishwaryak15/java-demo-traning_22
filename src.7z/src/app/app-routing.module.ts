import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmpDetailsComponent } from './emp-details/emp-details.component';

const routes: Routes = [{path:'getAllEmployees' ,component:EmpDetailsComponent},
{path:'**' ,component:Error}]; //here error is pagenotfound component

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

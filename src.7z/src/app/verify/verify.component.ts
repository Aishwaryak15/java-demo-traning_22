import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-verify',
  templateUrl: './verify.component.html',
  styleUrls: ['./verify.component.css']
})
export class VerifyComponent implements OnInit {
  userData:any = localStorage.getItem("currentUser");
  user = JSON.parse(this.userData);
  verificationUser:any; 
  baseurl = "http://localhost:8082/";

  constructor(private _http:HttpClient) { }

  ngOnInit(): void {
    console.log(this.user);
    

  }

  verify(){
    console.log("inside verify");
    this._http.post(this.baseurl+"getCode",this.user.userEmail).subscribe(resp=>{
      this.verificationUser = resp;
      console.log(this.verificationUser);
      this._http.get(this.baseurl+"verify?code="+this.verificationUser.verificationCode).subscribe(resp=>console.log(resp));
    })
    
  }
}

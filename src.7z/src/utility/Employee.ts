export interface Employee {

    empid:number;
    name:string;
    designation:string;
    image:string;
    flag:boolean
}